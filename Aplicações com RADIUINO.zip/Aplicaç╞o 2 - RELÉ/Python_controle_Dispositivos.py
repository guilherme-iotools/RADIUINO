# PROGRAMA PARA APLICA��O DO AP1
import serial
import math
import time
import struct
from time import localtime, strftime

# Configura a serial
n_serial = raw_input("Digite o n�mero da serial = ") #seta a serial
ser = serial.Serial("com"+n_serial, 9600, timeout=0.5,parity=serial.PARITY_NONE) # seta valores da serial

# Identifica��o da base
#ID_base = raw_input('ID_base = ')
ID_base = 0

# Cria o vetor Pacote
Pacote = {}


# Cria Pacote de 52 bytes com valor zero em todas as posi��es
for i in range(0,52): # faz um array com 52 bytes
   Pacote[i] = 0

Pacote [37] = 0
while True:
   try:

      # Imprime na tela o menu de op��es
      print 'Escolha um comandos abaixos e depois enter'
      print '1 - Ligar LED verde:'
      print 's - Para sair:'

      Opcao = raw_input('Entre com a Op��o = ')

      # Limpa o buffer da serial
      ser.flushInput()

      # Coloca no pacote o ID_base    
      Pacote[10] = int(ID_base)
     
      # ligar Rel�
      if Opcao == "1":
         #ID_sensor = raw_input('ID_sensor = ')  # Identifica��o do sensor a ser acessado
         ID_sensor = 1
         Pacote[8] = int(ID_sensor) # Coloca no pacote o ID_sensor
         Pacote[37] = 1        
         
         for k in range(0,52): # transmite pacote
            TXbyte = chr(Pacote[k])
            ser.write(TXbyte)
         # Aguarda a resposta do sensor
         time.sleep(0.3)

      # desligar Rel�
      if Opcao == "0":
         #ID_sensor = raw_input('ID_sensor = ')  # Identifica��o do sensor a ser acessado
         ID_sensor = 1
         Pacote[8] = int(ID_sensor) # Coloca no pacote o ID_sensor
         Pacote[37] = 0        
         
         for k in range(0,52): # transmite pacote
            TXbyte = chr(Pacote[k])
            ser.write(TXbyte)
         # Aguarda a resposta do sensor
         time.sleep(0.3)
         


      if Opcao == "s" or Opcao == "S":# caso o caracter digitado for s          
         ser.close() # fecha a porta COM
         print 'Fim da Execu��o'  # escreve na tela
         break
            
   except KeyboardInterrupt:
       #S.close()
       ser.close()

       break

