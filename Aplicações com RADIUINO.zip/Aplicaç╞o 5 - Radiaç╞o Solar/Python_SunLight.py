# PROGRAMA PARA APLICA��O DO AP1
import serial
import math
import time
import struct
from time import localtime, strftime

# Configura a serial
n_serial = raw_input("Digite o n�mero da serial = ") #seta a serial
ser = serial.Serial("com"+n_serial, 9600, timeout=0.5,parity=serial.PARITY_NONE) # seta valores da serial

# Identifica��o da base
ID_base = raw_input('ID_base = ')

# Cria o vetor Pacote
Pacote = {}

#Cria o vetor para salvar os valores das pot�ncias
listaPotDesviod ={}
listaPotDesviou ={}


# Cria Pacote de 52 bytes com valor zero em todas as posi��es
for i in range(0,52): # faz um array com 52 bytes
   Pacote[i] = 0

while True:
   try:
      #Inicializa��o das variaveis
      
      contador_tot = 0
      contador_pot = 0
      potmediad = 0.0
      potacumulad = 0.0
      potmeddbd = 0.0
      contador_err = 0
      potmediau = 0.0
      potacumulau = 0.0
      potmeddbu = 0.0
      PER = 0

      AcumDPd = 0
      AcumDPu = 0
      AcumVad = 0
      AcumVau = 0
      MedDPd = 0
      MedDPu = 0
      DPd = 0
      DPu = 0
      

      PotMaxd = -200
      PotMind = 10

      PotMaxu = -200
      PotMinu = 10


      # Imprime na tela o menu de op��es
      print 'Escolha um comandos abaixos e depois enter'
      print '1 - Realiza medidas:'
      print 's - Para sair:'

      Opcao = raw_input('Entre com a Op��o = ')

      # Limpa o buffer da serial
      ser.flushInput()

      # Coloca no pacote o ID_base
      
      Pacote[10] = int(ID_base)
      #Pacote[37] = 1    #Se voce estiver utilizando a placa de aplica��o DK101, descomente essa instru��o. O Pacote[37] � o byte 37 do pacote e � respons�vel por acionar o sensor de luminosidade LDR 


      # Leitura de temperatura e luminosidade
      if Opcao == "1":
         ID_sensor = raw_input('ID_sensor = ')  # Identifica��o do sensor a ser acessado
         Pacote[8] = int(ID_sensor) # Coloca no pacote o ID_sensor
         num_medidas = raw_input('Entre com o n�mero de medidas = ')

         print "Escolha qual radio voce esta utilizando: "
         print '0 - RFBee/BE900'
         print '1 - BE990'
         
         Tipo_radio = raw_input('Escolha sua op��o: ')
         
         if Tipo_radio == "0":
              rssioffset = 74
         elif Tipo_radio == "1":
              rssioffset = 81
         else:
              print "Escolha invalida utilizando configura��o do BE900"
              rssioffset = 74
         
         w = int(num_medidas)
         
         for j in range(0,w):    #Inicializa uma lista para gravar as pot�ncias e calcular o desvio padr�o
            listaPotDesviod[j] = 0
            listaPotDesviou[j] = 0

         filename1 = strftime("Sensor_%Y_%m_%d_%H-%M-%S.txt")
         print "Arquivo de log: %s" % filename1
         S = open(filename1, 'w')        
         
         for j in range(0,w):
            for k in range(0,52): # transmite pacote
               TXbyte = chr(Pacote[k])
               ser.write(TXbyte)
            # Aguarda a resposta do sensor
            time.sleep(0.1)

            line = ser.read(52) # faz a leitura de 52 bytes do buffer que recebe da serial pela COM
            if len(line) == 52:

               rssid = ord(line[0]) # RSSI_DownLink
               rssiu = ord(line[2]) # RSSI_UpLink
         
               #RSSI Downlink
               if rssid > 128:
                  RSSId=((rssid-256)/2.0)-rssioffset
            
               else:
                  RSSId=(rssid/2.0)-rssioffset

               #RSSI Uplink
               if rssiu > 128:
                  RSSIu=((rssiu-256)/2.0)-rssioffset
            
               else:
                  RSSIu=(rssiu/2.0)-rssioffset

               count = ord(line[12])      # contador de pacotes enviados pelo sensor

               # Leitura do AD0
               ad0t = ord(line[16]) # tipo de sensor - no caso est� medindo temperatura 
               ad0h = ord(line[17]) # alto
               ad0l = ord(line[18]) # baixo
               AD0 = ad0h * 256 + ad0l # Montanto a informa��o novamente. lembre-se que que as vari�veis de 2 bytes foram quebradas para caber em dois bytes pacote 
               visible = AD0
   
               # Leitura do AD1
               ad1t = ord(line[19]) # tipo de sensor - no caso est� medindo LDR
               ad1h = ord(line[20]) # alto
               ad1l = ord(line[21]) # baixo
               AD1 = ad1h * 256 + ad1l # Montanto a informa��o novamente. lembre-se que que as vari�veis de 2 bytes foram quebradas para caber em dois bytes pacote
               ir = AD1

               # Leitura do AD2
               ad2t = ord(line[22]) # tipo de sensor - no caso est� medindo LDR
               ad2h = ord(line[23]) # alto
               ad2l = ord(line[24]) # baixo
               AD2 = ad2h * 256 + ad2l # Montanto a informa��o novamente. lembre-se que que as vari�veis de 2 bytes foram quebradas para caber em dois bytes pacote
               uv = AD2/100.0

               
               if RSSId > PotMaxd:
                  PotMaxd = RSSId
               
               if RSSId < PotMind:   
                  PotMind = RSSId

               if RSSIu > PotMaxu:
                  PotMaxu = RSSIu
               
               if RSSIu < PotMinu:   
                  PotMinu = RSSIu
               
               
               listaPotDesviod[contador_pot]= RSSId   #Grava a pot�ncia de downlink para c�lculo do desvio padr�o
               listaPotDesviou[contador_pot]= RSSIu   #Grava a pot�ncia de uplink para c�lculo do desvio padr�o

               contador_pot=contador_pot+1 #incrementa o contador utilizado para a m�dia de pot�ncia e para o desvio padr�o

               potmwd = pow(10,(RSSId/10))   #converte a pot�ncia de downlink em dBm para mW.
               potacumulad = potacumulad + potmwd  #Soma a pot�ncia em mW em um acumulador

               potmwu = pow(10,(RSSIu/10))   #converte a pot�ncia de uplink em dBm para mW
               potacumulau= potacumulau + potmwu

               
               
               print'N�mero do pacote = ',count, 'RSSI DownLink = ', RSSId, '  RSSI UpLink ', RSSIu, ' Visible = ', visible, '  IR = ',ir, ' UV= ' , uv          
               print >>S,time.asctime(),'N�mero do pacote = ',count, 'RSSI DownLink = ', RSSId, '  RSSI UpLink ', RSSIu, ' Visible = ', visible, '  IR = ',ir, 'UV= ' , uv 
               time.sleep(0.2)
               
            else:
               contador_err = contador_err + 1
               print ' erro'
               print >>S,time.asctime(),' erro'
               ser.flushInput()
               time.sleep(0.2)

            contador_tot = contador_tot + 1
            #time.sleep(1)


         
         for l in range(0,contador_pot):
            AcumVad =AcumVad+ listaPotDesviod[l]   #acumula o valor da lista para calcular a m�dia
            AcumVau =AcumVau+ listaPotDesviou[l]   #acumula o valor da lista para calcular a m�dia

         MedDPd = float (AcumVad)/float(contador_pot)
         MedDPu = float (AcumVau)/float(contador_pot)

         for m in range(0,contador_pot):
            AcumDPd =AcumDPd+ pow((listaPotDesviod[m]- MedDPd),2)   #acumula o valor da variancia
            AcumDPu =AcumDPu+ pow((listaPotDesviou[m]- MedDPu),2)  #acumula o valor da variancia

         DPd = float (AcumDPd)/float(contador_pot)   #termina o calculo da variancia
         DPu = float (AcumDPu)/float(contador_pot)   #termina o calculo da variancia

         potmediad = potacumulad /contador_pot
         potmeddbd = 10*math.log10(potmediad)
         #print ' A Pot�ncia m�dia de downlink foi:', potmediad , ' mW'
         print 'A Pot�ncia m�dia de Downlink em dBm foi:', potmeddbd,' dBm'
         print 'A Pot�ncia M�xima de Downlink em dBm foi:', PotMaxd,' dBm'
         print 'A Pot�ncia M�nima de Downlink em dBm foi:', PotMind,' dBm'
         print 'O Desvio Padr�o do sinal de Downlink foi:', DPd
         
         print >>S,time.asctime(),' A Pot�ncia m�dia de Downlink em dBm foi:', potmeddbd,' dBm'
         print >>S,time.asctime(),'A Pot�ncia M�xima de Downlink em dBm foi:', PotMaxd,' dBm'
         print >>S,time.asctime(),'A Pot�ncia M�nima de Downlink em dBm foi:', PotMind,' dBm'
         print >>S,time.asctime(),'O Desvio Padr�o do sinal de Downlink foi:', DPd


         potmediau = potacumulau /contador_pot
         potmeddbu = 10*math.log10(potmediau)
         #print ' A Pot�ncia m�dia de Uplink foi:', potmediau , ' mW'
         print 'A Pot�ncia m�dia de Uplink em dBm foi:', potmeddbu,' dBm'
         print 'A Pot�ncia M�xima de Uplink em dBm foi:', PotMaxu,' dBm'
         print 'A Pot�ncia M�nima de Uplink em dBm foi:', PotMinu,' dBm'
         print 'O Desvio Padr�o do sinal de Uplink foi:', DPu

         
         print >>S,time.asctime(),' A Pot�ncia m�dia de Uplink em dBm foi:', potmeddbu,' dBm'
         print >>S,time.asctime(),'A Pot�ncia M�xima de Uplink em dBm foi:', PotMaxu,' dBm'
         print >>S,time.asctime(),'A Pot�ncia M�nima de Uplink em dBm foi:', PotMinu,' dBm'
         print >>S,time.asctime(),'O Desvio Padr�o do sinal de Uplink foi:', DPu


         

         PER = (float(contador_err)/float(contador_tot))* 100
         print 'A PER foi de:', float(PER),'%'
         print >>S,time.asctime(),'A PER foi de:', float(PER),'%'
         
         S.close()

      if Opcao == "s" or Opcao == "S":# caso o caracter digitado for s          
         ser.close() # fecha a porta COM
         print 'Fim da Execu��o'  # escreve na tela
         break
            
   except KeyboardInterrupt:
       S.close()
       ser.close()

       break

