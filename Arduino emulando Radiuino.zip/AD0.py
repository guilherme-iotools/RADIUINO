# MEDINDO O CONVERSOR ANALOGICO-DIGITAL A0 DO ARDUINO UNO

# IMPORTA AS BIBLIOTECAS
import serial
import math
import time
import struct
from time import localtime, strftime

# Configura a serial
# para COM# o n�mero que se coloca � n-1 no primeiro par�metrso. Ex COM9  valor 8
n_serial = raw_input("Digite o n�mero da serial = ") #seta a serial
#n_serial1 = int(n_serial) - 1
ser = serial.Serial("COM"+n_serial, 9600, timeout=0.5,parity=serial.PARITY_NONE) # seta valores da serial

# Identifica��o da base
#ID_base = raw_input('ID_base = ')
ID_base = 0

# Identifica��o do sensor a ser acessado
#ID_sensor = raw_input('ID_sensor = ')
ID_sensor = 1

# Cria o vetor Pacote
PacoteTX = {}
PacoteRX = {}

# Cria Pacote de 52 bytes com valor zero em todas as posi��es
for i in range(52): # faz um array com 52 bytes
   PacoteTX[i] = 0
   PacoteRX[i] = 0

while True:
   try:

      # Imprime na tela o menu de op��es
      print 'Escolha um comandos abaixos e depois enter'
      print '1 - Realiza medida do AD0:'
      print 's - Para sair:'

      Opcao = raw_input('Entre com a Op��o = ')

      # Limpa o buffer da serial
      ser.flushInput()

      # Coloca no pacote o ID_sensor e ID_base
      PacoteTX[8] = int(ID_sensor)
      PacoteTX[10] = int(ID_base)

      # Leitura de umidade do solo
      if Opcao == "1":
         Total_de_Medidas = raw_input('Entre com o n�mero de medidas do AD0 = ')
         
         # CRIA ARQUIVO DE LOG
         filename1 = strftime("AD0_%Y_%m_%d_%H-%M-%S.txt")
         print "Arquivo de log dO AD0: %s" % filename1
         Log = open(filename1, 'w')

         # FOR PARA REALIZAR AS MEDIDAS.
         for j in range(int(Total_de_Medidas)):
            # TRANSMISS�O DO PACOTE
            for k in range(52): # transmite pacote
               TXbyte = chr(PacoteTX[k])
               ser.write(TXbyte)
            # Aguarda a resposta do sensor
            time.sleep(0.1)

            PacoteRX = ser.read(52) # faz a leitura de 52 bytes do buffer que recebe da serial pela COM

            if len(PacoteRX) == 52:

               # Retira do pacote os bytes 17 e 18, que est�o com o valor inteiro e o resto
               ad0h = ord(PacoteRX[17]) # inteiro
               ad0l = ord(PacoteRX[18]) # resto                            
               AD0 = ad0h * 256 + ad0l
               
           
            print time.asctime(),'   Medida = ',j,'   AD0 =', AD0
            print >>Log,time.asctime(),'=  Medida =',j,'AD0 = ',AD0
            time.sleep(1)

         Log.close()

      if Opcao == "s" or Opcao == "S":# caso o caracter digitado for s          
         ser.close() # fecha a porta COM
         print 'Fim da Execu��o'  # escreve na tela
         Log.close()
         break
            
   except KeyboardInterrupt:
       ser.close()
       Log.close()
       break

